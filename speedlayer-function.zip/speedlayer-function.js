//START
'use strict';

console.log('Loading function');

const aws = require('aws-sdk');
const firehose = new aws.Firehose();
const s3 = new aws.S3({ apiVersion: '2006-03-01' });

function sendToFirehose(recordsForFirehose){
    var paramsFirehose = {
        DeliveryStreamName: process.env.DELIVERY_STREAM_NAME, // required
        Records: recordsForFirehose
    };
    console.log(recordsForFirehose);
    firehose.putRecordBatch(paramsFirehose, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else     console.log(data);           // successful response
    });
}

function manageData(csvData){
    var recordsForFirehose = new Array();
    var lines = csvData.split("\n"); 
    var i = 0 ;
    var errors = 0 ;
    lines.forEach(function(line) {
        if (line!==""){
            try{
                var fields = line.split("|");
                var isoDate = null ;
                isoDate = new Date(fields[4]).toISOString() ;  
                var recordForFirehose = {
                    id : fields[0],
                    name : fields[1],
                    text : fields[2],
                    date: isoDate,
                    isodate: fields[4],
                    time: fields[3]
                };
                recordsForFirehose[i] = {Data:JSON.stringify(recordForFirehose)} ;
                i++;
            }catch(e){
                errors++;
            }
        }
    });
    console.log("errors:"+errors);
    sendToFirehose(recordsForFirehose)

}

exports.handler = (event, context, callback) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));

    // Get the object from the event and show its content type
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const params = {
        Bucket: bucket,
        Key: key,
    };
    s3.getObject(params, (err, data) => {
        if (err) {
            console.log(err);
            const message = `Error getting object ${key} from bucket ${bucket}. Make sure they exist and your bucket is in the same region as this function.`;
            console.log(message);
            callback(message);
        } else {
            console.log('CONTENT TYPE:', data.ContentType);
            manageData(data.Body.toString('ascii'));
            callback(null, data.ContentType);
        }
    });
};
//END
